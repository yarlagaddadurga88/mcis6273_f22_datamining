# QUESTIONS TO DO

## Listen to the podcast / watch the video and write a 3-5 sentence reaction to the podcast. State in your own words what you learned, what expanding your knowledge of the topic and what you found interesting about the information you received

- ObservableHQ has helped create a tool for both building complex data dashboards for visualisation and a collaboroative tool to share and learn from the projects hosted by the community. What is interesting for me is that the platform is also forms a space to connect with other developers share data and different templates for visualising data differently.

## Task: Go to observablehq.com and find ONE project. With the one project please enumerate the following

(a) please give the title, URL and description of the project on Observable,

 - **Title** : _How Has Men’s Tennis Changed From 1973–2021?_
  
 - **Url**   : _<https://observablehq.com/@unkleho/how-has-mens-tennis-changed-from-1973-2021>_
  

  b) describe the datasets used in the project (you can just provide 1 sentence summary of the dataset)
It is a dataset of Male Tennis players and how there are notable changes in their patterns and physical appearance.


(c) provide a brief description of the visualizations used (1 sentence),

The data shows a comparison of different forms of hands used by the players, aggregating between countries, time, their ranking as tennis players, their height and weight.

(d) describe why you found this dataset / project interesting (no more than 2 sentences)

I love sports and the project I picked was catchy for me as a far of fan of Tennis.
